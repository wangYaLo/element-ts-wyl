import zbCaster from './src/index';
export default zbCaster
