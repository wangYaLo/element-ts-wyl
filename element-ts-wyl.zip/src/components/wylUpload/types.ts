export interface raw_type {
  uid: number;
  lastModified: number;
  lastModifiedDate: Date;
  name: string;
  size: number;
  type: string;
  webkitRelativePath: string;
}

export interface File_All {
  name: string;
  percentage: number;
  raw: raw_type;
  response: response_All
  size: number;
  status: string;
  uid: number;
}
export interface response_All {
  code: number;
  msg: string | null;
  data: { docuId: string, url: string };
}

// 上传前事件
export function gethandleBeforeUpload(file: raw_type, that: NewVue2): Promise<boolean> {
  return new Promise((reslove, reject) => {
    const filetype: any = (FileType as FileType_Type).fromBlob(file);
    filetype.then((res: any) => {
      if (res == undefined) {
        res = { ext: '' };
      }
      if (['png', 'jpg', 'webp', 'gif', 'ppt', 'pptx', 'xls', 'xlsx', 'pdf', 'doc', 'docx'].findIndex((e) => e == res.ext) != -1 || (file.type == 'text/plain' && res.ext == '')) {
        if (file.size * 1 > 1048576) {
          // 10485760
          that.$message({
            message: that.$t('fileTooLarge') as string,
            type: 'error'
          });
          reject()
        } else {
          const formData = new FormData();
          formData.append('client_id', 'client');
          formData.append('client_secret', '123456');
          formData.append('grant_type', 'refresh_token');
          formData.append('refresh_token', window.localStorage.getItem('REFRESH_TOKEN') as any);
          const ele: any = getToken(formData);
          ele.then((res: any) => {
            if (res.code === '200') {
              that.headers.Authorization = `Bearer ${ ele.accessToken }`;
              window.localStorage.setItem('ACCESS_TOKEN', ele.accessToken);
              window.localStorage.setItem('REFRESH_TOKEN', ele.refreshToken);
              reslove(true)
            } else if (ele.code === 'A0230') {
              that.$EventBus.$emit('tokenover');
              reject()
            } else {
              reject()
            }
          })
        }
      } else {
        that.$message({
          type: 'error',
          message: that.$i18n.locale === 'zh' ? '请上传正确类型的文件' : 'Please upload the correct type file.'
        });
        reject()
      }
    })
  })
}
