import wylUpload from './combination.vue';
export default wylUpload;
