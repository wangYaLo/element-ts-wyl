import xdmCaster from './caster.vue';
export default xdmCaster;
